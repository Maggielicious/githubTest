package strenger;

import javax.swing.*;

public class Strenger {
    public static void main(String [] args){
        String forNavn = JOptionPane.showInputDialog("Hva er fornavnet ditt?");
        String etterNavn = JOptionPane.showInputDialog("Hva er etternavnet ditt?");
        String adresse = JOptionPane.showInputDialog("Hva er adressen din?");
        String postNummer = JOptionPane.showInputDialog("Hva er postnummeret ditt?");
        String postSted = JOptionPane.showInputDialog("Hva er poststedet ditt?");
        String alder = JOptionPane.showInputDialog("Hvor gammel er du?");
        String fNavn = forNavn +" "+ etterNavn;

        System.out.println(fNavn + " bor i " + adresse + " som har postnummer " + postNummer + " i " + postSted + ". " + forNavn + "'s alder er " + alder +" år.");

        System.out.println("Navn: " + fNavn);
        System.out.println("Adresse: " + adresse);
        System.out.println("Postnummer: " + postNummer);
        System.out.println("Poststed: " + postSted);
        System.out.println("Alder: " + alder);
    }
}
